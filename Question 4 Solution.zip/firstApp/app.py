from flask import Flask
from flask_mysqldb import MySQL

app = Flask(__name__)

app.config['MYSQL_USER'] = 'sql6415950'
app.config['MYSQL_PASSWORD'] = 'lsDw8IvLba'
app.config['MYSQL_HOST']='sql6.freemysqlhosting.net'
app.config['MYSQL_DB']='sql6415950'
app.config['MYSQL_CURSORCLASS']='DictCursor'



mysql = MySQL(app)


@app.route('/')
def index():
    cur = mysql.connection.cursor()
    #cur.execute('''CREATE TABLE students (name VARCHAR(20), email VARCHAR(20))''')
    #cur.execute('''DROP TABLE scores''')
    #cur.execute('''CREATE TABLE scores (name VARCHAR(20), first INTEGER, second INTEGER, third INTEGER, total INTEGER)''')
    return 'Done!'


@app.route('/insert/<string:candidateName>/<string:candidateEmail>', methods=['POST'])
def insert(candidateName, candidateEmail):
    cur = mysql.connection.cursor()
    route = "INSERT INTO students (name, email) VALUES ('" + candidateName + "', '" + candidateEmail + "')"
    print(route)
    cur.execute(route)
    mysql.connection.commit()
    return 'Done!'

@app.route('/view', methods=['GET'])
def view():
    cur = mysql.connection.cursor()
    cur.execute('''SELECT * FROM students''')
    results = cur.fetchall()
    print(results)
    return 'Done!'

@app.route('/viewScores', methods=['GET'])
def viewScores():
    cur = mysql.connection.cursor()
    cur.execute('''SELECT * FROM scores''')
    results = cur.fetchall()
    print(results)
    return 'Done!'

@app.route('/assignScore/<string:candidateName>/<string:first>/<string:second>/<string:third>', methods=['Post'])
def assign(candidateName,first, second, third):
    cur = mysql.connection.cursor()
    route = "INSERT INTO scores (name,first,second,third,total) VALUES ('" + candidateName + "', '" + first + "', '" + second + "', '" + third + "','" + str(int(first)+int(second)+int(third)) + "')"
    print(route)
    cur.execute(route)
    mysql.connection.commit()
    return 'Done!'

@app.route('/highestScorer', methods=['GET'])
def highestScorer():
    cur = mysql.connection.cursor()
    route = "SELECT name FROM scores WHERE total = (SELECT MAX(total) FROM scores)"
    print(route)
    cur.execute(route)
    results = cur.fetchall()
    print(results)
    mysql.connection.commit()
    return 'Done!'


@app.route('/averageScores', methods=['GET'])
def averageScores():
    cur = mysql.connection.cursor()
    route = "SELECT AVG(first), AVG(second), AVG(third) FROM scores"
    print(route)
    cur.execute(route)
    results = cur.fetchall()
    print(results)
    mysql.connection.commit()
    return 'Done!'
